import  os
s_version=os.name
st_version=str(s_version)
#-----------------------------------------------------------------------------------------------------------------------
def s_determin(s_version):
    if st_version == "nt":
        print("System version = Windows")
    if st_version == "posix":
        print("System version = Linux/mac")
#-----------------------------------------------------------------------------------------------------------------------
def Server_start():
    directory = os.getcwd()  # 获取当前文件目录
    out_directory = os.listdir(directory)  # 获取当前目录下所有文件与目录名
    command = os.system("java -jar mohist-1.16.5-1095-server.jar")
#-----------------------------------------------------------------------------------------------------------------------










