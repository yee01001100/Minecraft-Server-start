import os.path
import shutil
import main as m
m.s_determin(m.s_version)#判断当前系统类型
s_directory = os.getcwd()#获取当前文件目录（Server）
out_s_directory = os.listdir(s_directory)#获取目录Server下所有文件
L = out_s_directory.count("mohist-1.16.5-1095-server.jar")#判断1.16.5服务端文件是否存在
if L > 0:
    m.Server_start()
    input()
else:
    shutil.copy("..\mohist-1.16.5-1095-server.jar","mohist-1.16.5-1095-server.jar")
    m.Server_start()